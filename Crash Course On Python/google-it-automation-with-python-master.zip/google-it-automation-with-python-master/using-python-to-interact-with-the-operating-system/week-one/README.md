# Using Python to Interact with the Operating System - Week 1

## Getting Ready for Python

---

## Runnig Python Locally

---

## Automating Tasks Through Programming


---

## Credit
* [Coursera - Python Operating System Week 1](https://www.coursera.org/learn/python-operating-system/home/week/1)